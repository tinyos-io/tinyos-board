#ifndef __MY_BOARD_H
#define __MY_BOARD_H

#define GPIO_PIN_12   12
#define GPIO_PIN_13   13
#define GPIO_PIN_14   14
#define GPIO_PIN_15   15


#define LED_4 GPIO_PIN_12
#define LED_3 GPIO_PIN_13
#define LED_5 GPIO_PIN_14
#define LED_6 GPIO_PIN_15

#endif 