$Id: README.txt,v 1.1 2008/06/23 21:06:14 sallai Exp $

README for TestPowerup
Author/Contact: tinyos-help@millennium.berkeley.edu

Description:

The TestPowerup application turns on LED 0 when the mote boots successfully,
i.e. when MainC signals the booted event. It is a useful sanity test when
developing a new platform.

Tools:

None.

Known bugs/limitations:

None.
 