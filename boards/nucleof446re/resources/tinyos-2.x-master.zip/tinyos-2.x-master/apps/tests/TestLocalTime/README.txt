README for TestLocalTime
Author/Contact: tinyos-help@millennium.berkeley.edu

Description:

TestLocalTime is a simple application that tests the LocalTimeMilliC component
by sending the current time over the serial port once per second.

dump.py is a Python script that can be used to read and format the values from
the serial port.

Tools:

None.

Known bugs/limitations:

None.

