#ifndef __TESTDIP_H__
#define __TESTDIP_H__

enum {
  AM_TESTDIP = 0xAB
};

#endif
