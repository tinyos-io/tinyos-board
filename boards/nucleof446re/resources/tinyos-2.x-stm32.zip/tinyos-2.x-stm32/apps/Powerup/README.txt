$Id: README.txt,v 1.4 2006/12/12 18:22:48 vlahan Exp $

README for Powerup
Author/Contact: tinyos-help@millennium.berkeley.edu
@author Cory Sharp <cssharp@eecs.berkeley.edu>

Description:

Powerup turns on the red LED on powerup.  It is useful to test that the
build environment is functional and that an application correctly installs
on a piece of hardware.

Tools:

None.

Known bugs/limitations:

None.

